import React from 'react' ;
import {View, Text, Image, ScrollView, TextInput} from 'react-native' ;

const App = () => {
  return (
    <ScrollView>
    <View style={{
    justifyContent: 'center',
    alignItems: 'center',
    }}>
   
   
   
    <Text> henyooooww </Text>
   
    <Text> mEOw</Text>
    <Image
    source={{
      uri: 'https://static.displate.com/857x1200/displate/2023-02-11/6b4acdc5c830924d14c62f1e9be12019_680ebd38f5d718193f662504129ce447.jpg' ,
    }}
    style={{width: 200, height: 200}}
    />
    </View>
    <TextInput
    style={{
      height: 40,
      borderColor: 'gray',
      borderWidth: 1,
      textAlign: 'center'
    }}
    defaultValue="meow meow meow"
    />
    </ScrollView>
   
  );
};
export default App;
